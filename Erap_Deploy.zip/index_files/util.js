﻿// ****************************** [ MDGov_Util GLOBAL LIBRARY ] ****************************** //
ewfRequire.define("lib/util", ['ewfJquery', 'bootstrap'], function ($) {

    return {

        urlParams: {},

        parseUrlParams: function () {
            var match,
            pl = /\+/g,  // Regex for replacing addition symbol with a space
            search = /([^&=]+)=?([^&]*)/g,
            decode = function (s) { return decodeURIComponent(s.replace(pl, " ")); },
            query = window.location.search.substring(1);
            while (match === search.exec(query))
                this.urlParams[decode(match[1])] = decode(match[2]);
        },

        // Scrolls document to hash ID
        scrollToHash: function (hash, callback) {
            var offset = ($(hash).offset().top - ($('#mdgov_ent_header').outerHeight() + 20));
            $('html,body').animate({
                scrollTop: offset
            }, 'slow', callback);
        },

        showTooltip: function (options, el) {

            options = options || {};
            el = el || "#mdgov_dropTip";

            var settings = {
                html: true,
                placement: 'bottom',
                trigger: 'manual'
            };

            $.extend(settings, options);

            var tip = $(el).popover(settings);
            tip.popover('show');

            // Bind tip events
            tip.on("shown.bs.popover", function () {
                $('#tipDismiss').on("click", function (e) {
                    if (e.preventDefault()) { e.preventDefault(); }
                    tip.popover('destroy');
                });
            });

            return tip;

        },

        hideTooltip: function (el) {
            el = el || "#mdgov_dropTip";
            $(el).popover('hide');
        },

        destroyTooltip: function (el) {
            el = el || "#mdgov_dropTip";
            $(el).popover('dispose'); 
        },

        // Creates browser cookie
        createCookie: function (name, value, days) {
            var expires;
            if (days) {
                var date = new Date();
                date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                expires = "; expires=" + date.toGMTString();
            }
            else {
                expires = "";
            }
            document.cookie = name + "=" + value + expires + "; path=/";
        },

        // Creates a session cookie
        createSessionCookie: function (name, value) {
            document.cookie = name + "=" + value + ";path=/";
        },

        // Reads a cookie
        readCookie: function (name) {
            var nameEq = name + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1, c.length);
                if (c.indexOf(nameEq) == 0) return c.substring(nameEq.length, c.length);
            }
            return null;
        },

        eraseCookie: function (name) {
            this.createCookie(name, "", -1);
        },

        trimString: function (str) {
            if (str) {
                str = str.replace(/^\s+/, '');
                for (var i = str.length - 1; i >= 0; i--) {
                    if (/\S/.test(str.charAt(i))) {
                        str = str.substring(0, i + 1);
                        break;
                    }
                }
            }
            return str;
        },

        processTabbing: function () {
            $(":focusable").on("focus blur", function (e) {
                var $this = $(this);
                $this.toggleClass('linkFocused');
            }).on("click", function () {
                $(this).removeClass("linkFocused");
            });
        },

        buildAriaMenus: function (scope) {

            var keyCodes = {
                tab: 9,
                enter: 13,
                esc: 27,
                space: 32,
                left: 37,
                up: 38,
                right: 39,
                down: 40
            },

            menuItemSelector = '[role^="menuitem"], [role^="button"]';

            scope = scope || $('[role^="menu"], [role^="toolbar"]');

            scope.find(menuItemSelector).on("keyup", function (e) {

                var $menuItem = $(this),
                prevLink = ($menuItem.prev(menuItemSelector).length > 0) ? $menuItem.prev(menuItemSelector) : $menuItem.parent().prev().find(menuItemSelector),
                nextLink = ($menuItem.next(menuItemSelector).length > 0) ? $menuItem.next(menuItemSelector) : $menuItem.parent().next().find(menuItemSelector);

                switch (e.which) {
                    case keyCodes["left"]:
                    case keyCodes["up"]:
                        if (e.preventDefault()) { e.preventDefault(); }
                        prevLink.focus();
                        break;
                    case keyCodes["right"]:
                    case keyCodes["down"]:
                        if (e.preventDefault()) { e.preventDefault(); }
                        nextLink.focus();
                        break;
                    case keyCodes["tab"]:
                        break;
                    case keyCodes["space"]:
                        if (e.preventDefault()) { e.preventDefault(); }
                        $menuItem.trigger("click");
                        break;
                    case keyCodes["enter"]:
                        break;
                    case keyCodes["esc"]:
                        break;
                }

            });

        },

        truncateStr: function (str, len) {
            str = $.trim(str);
            if (str.length > len) {
                str = str.substring(0, len) + "...";
            }
            return str;
        },

        registerFormButton: function (input, button) {
            var $input = $(input),
            $button = $(button);
            $input.on('keyup', function (e) {
                if (e.which == 13) {
                    if (e.preventDefault) {
                        e.preventDefault();
                    }
                    $button.trigger('click');
                }
                return false;
            });
        },

        trackEvent: function (category, action, label, callback) {
            if (typeof (window.ewfTracker) == "function" && window.gaAvailable == true) {
                // Setup callback
                var optional = {};
                if (typeof (callback) == "function") {
                    optional = {
                        'hitCallback': callback
                    };
                }

                // Call tracker
                window.ewfTracker('send', 'event', category, action, label, optional);
            } else if (typeof (callback) == "function") {
                console.log("Event NOT tracked...");
                callback();
            }
        }

    }
});